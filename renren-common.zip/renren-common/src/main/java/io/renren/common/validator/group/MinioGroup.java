package io.renren.common.validator.group;

/**
 * Minio
 */
public interface MinioGroup {
}
